package com.example.ontum_tv_launcher

import io.flutter.embedding.android.FlutterActivity


class MainActivity: FlutterActivity() {



}
