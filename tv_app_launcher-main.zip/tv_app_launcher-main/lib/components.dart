import 'package:app_settings/app_settings.dart';
import 'package:device_apps/device_apps.dart';
import 'package:flutter/material.dart';
import 'package:ontum_tv_launcher/Components/AllAppsSections.dart';
import 'package:ontum_tv_launcher/Components/AppContainer.dart';
import 'package:ontum_tv_launcher/Config/index.dart';

Widget logo(width) {
  const flavour = String.fromEnvironment('FLAVOR', defaultValue: 'ONTUM');
  String logo = Config.getAppLogo();
  return Padding(
    padding:
        const EdgeInsets.symmetric(vertical: flavour == "ASPIRE" ? 0 : 10.0),
    child: Image.asset(
      logo,
      width: flavour == "ASPIRE" ? width * 0.25 : width * 0.15,
    ),
  );
}

Widget settingsIcons(double width, double height) {
  return Padding(
    padding: EdgeInsets.symmetric(horizontal: width * 0.02),
    child: Row(
      children: [
        InkWell(
            onTap: AppSettings.openDeviceSettings,
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.black38,
                  borderRadius: BorderRadius.circular(width * 0.02)),
              width: width * 0.3,
              height: height * 0.2,
              child: Row(
                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.settings,
                    size: width * 0.08,
                    color: Colors.white,
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Text(
                    "Settings",
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: width * 0.02,
                      color: Colors.white,
                    ),
                  )
                ],
              ),
            ))
      ],
    ),
  );
}

Widget showSingleSettingApp(
    app, double width, double height, List<Application> apps) {
  // print(apps)
  final double itemHeight = (height - kToolbarHeight - 26) / 2.5;
  final double itemWidth = width / 2;
  return InkWell(
    onTap: () {
      try {
        DeviceApps.openApp(app.packageName);
      } catch (e) {
        print(e.toString());
      }
    },
    child: Container(
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: Colors.black38,
          borderRadius: BorderRadius.circular(width * 0.02)),
      width: width * 0.3,
      height: 10,
      child: Row(
        children: [
          Image.memory(
            (app as ApplicationWithIcon).icon,
            width: 120,
          ),
          Text(
            app.appName,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: width * 0.02,
              color: Colors.white,
            ),
          )
        ],
      ),
    ),
  );
}

Widget allSettingsSections(double width, double height) {
  // print(apps)
  final double itemHeight = (height - kToolbarHeight - 26) / 2.5;
  final double itemWidth = width / 2;
  const List<Application> apps = [];
  return GridView.count(
    crossAxisCount: 3,
    childAspectRatio: (itemWidth / itemHeight),
    controller: ScrollController(keepScrollOffset: false),
    shrinkWrap: true,
    scrollDirection: Axis.vertical,
    children: apps
        .map((app) => showSingleSettingApp(app, width, height, apps))
        .toList(),
  );
}

Widget allAppIconsSections(
    double width, double height, List<Application> apps) {
  // print(apps)
  final double itemHeight = (height - kToolbarHeight - 26) / 2.5;
  final double itemWidth = width / 2;
  int? selectedIndex;
  int? onFocusIndex;
  return GridView.count(
    crossAxisCount: 3,
    childAspectRatio: (itemWidth / itemHeight),
    controller: ScrollController(keepScrollOffset: false),
    shrinkWrap: true,
    scrollDirection: Axis.vertical,
    children: apps
        .map(
          (app) => Focus(
            onFocusChange: ((value) {
              if (value) {
                print("TextField Two got focused.");
              } else {
                print("TextField Tow got unfocused.");
              }
            }),
            child: InkWell(
              onTap: () {
                try {
                  DeviceApps.openApp(app.packageName);
                } catch (e) {
                  print(e.toString());
                }
              },
              child: Container(
                margin: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: Colors.black38,
                    borderRadius: BorderRadius.circular(width * 0.02)),
                width: width * 0.3,
                height: 10,
                child: Row(
                  children: [
                    Image.memory(
                      (app as ApplicationWithIcon).icon,
                      width: 120,
                    ),
                    Text(
                      app.appName,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: width * 0.02,
                        color: Colors.white,
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        )
        .toList(),
  );
}

Widget showMainApp(double width, double height, ScrollController controller) {
  final double itemHeight = (height - kToolbarHeight - 26) / 2.5;
  final double itemWidth = width / 2;

  return Container(
    padding: EdgeInsets.symmetric(horizontal: width * 0.02),
    width: width,
    height: height * 0.6,
    child: Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
              Transform.translate(
          offset: Offset(
              15.0, 20.0), // Adjust the second parameter (10.0) as needed
          child: Text(
            "Apps",
            style: TextStyle(
              fontSize: width * 0.03,
              fontWeight: FontWeight.bold,
              color: const Color.fromRGBO(66, 86, 162, 1),
            ),
            textAlign: TextAlign.left,
          ),
        ),
        FutureBuilder(
          future: Config.getMainApps(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              List<Application?>? apps = snapshot.data;
              if (apps == null) {
                return const SizedBox.shrink();
              }

              return GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: (itemWidth / itemHeight),
                ),
                controller: controller,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                itemCount: apps.length,
                itemBuilder: ((context, index) {
                  final app = apps[index];
                  return AppContainer(height: height, width: width, app: app!);
                }),
              );
            }
            return const CircularProgressIndicator();
          },
        ),
      ],
    ),
  );
}

Widget adminForm(
    double width,
    BuildContext context,
    bool isAdmin,
    TextEditingController username,
    TextEditingController password,
    submitButton,
    bool selected,
    onSelected) {
  return Focus(
    onFocusChange: onSelected,
    child: Container(
      decoration: BoxDecoration(
          color:
              selected ? Colors.white38 : const Color.fromRGBO(66, 86, 162, 1),
          borderRadius: BorderRadius.circular(50)),
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      child: InkWell(
        onTap: () async {
          showDialog<void>(
            context: context,
            barrierDismissible: false, // user must tap button!
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text(!isAdmin ? 'Login' : 'Logout'),
                content: SingleChildScrollView(
                  child: ListBody(
                    children: isAdmin
                        ? const [SizedBox()]
                        : <Widget>[
                            TextField(
                              controller: username,
                              decoration: const InputDecoration(
                                icon: Icon(Icons.account_circle),
                                labelText: 'Username',
                              ),
                            ),
                            TextField(
                              obscureText: true,
                              controller: password,
                              decoration: const InputDecoration(
                                icon: Icon(Icons.lock),
                                labelText: 'Password',
                              ),
                            ),
                          ],
                  ),
                ),
                actions: <Widget>[
                  TextButton(
                    child: const Text('Close'),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                  submitButton(),
                ],
              );
            },
          );
        },
        child: Icon(
          Icons.account_circle_outlined,
          size: width * 0.05,
          color: Colors.white,
        ),
      ),
    ),
  );
}

Widget allAppsHeader(
  width,
  isAdmin,
) {
  return isAdmin
      ? Container(
          padding: EdgeInsets.all(width * 0.02),
          width: width,
          child: Text(
            "All Apps",
            style: TextStyle(
                fontSize: width * 0.03,
                fontWeight: FontWeight.bold,
                color: Colors.white),
            textAlign: TextAlign.left,
          ),
        )
      : const SizedBox.shrink();
}

Widget allApps(width, height, apps, isAdmin) {
  return isAdmin
      ? AllAppsSection(
          apps: apps,
          isAdmin: isAdmin,
          width: width,
          height: height,
        )
      : const SizedBox.shrink();
}

Widget footer() {
  const flavour = String.fromEnvironment('FLAVOR', defaultValue: 'ONTUM');
  if (flavour != "ONTUM") return const SizedBox.shrink();
  return Align(
    alignment: Alignment.bottomRight,
    child: Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          const Text(
            "Powered by",
            style: TextStyle(
                color: Colors.white, fontStyle: FontStyle.italic, fontSize: 15),
          ),
          Image.asset(
            "assets/images/ontum.png",
            width: 120,
            height: 30,
          )
        ],
      ),
    ),
  );
}
