import 'package:device_apps/device_apps.dart';
import 'package:flutter/material.dart';

class Config {
  static String getAppPackageName() {
    const flavour = String.fromEnvironment('FLAVOR', defaultValue: 'ONTUM');
    String packageName = "ontum.edu.app";
    if (flavour == "MEGHSHALA") packageName = "online.meghshala.edu";
    if (flavour == "ASPIRE") packageName = "ontum.aspire.edu";
    return packageName;
  }

  static AssetImage getAppBackgroundImage() {
    const flavour = String.fromEnvironment('FLAVOR', defaultValue: 'ONTUM');
    AssetImage image = const AssetImage("assets/images/ontum-background-2.png");

    if (flavour == "MEGHSHALA") {
      image = const AssetImage("assets/images/meghshala-background-2.png");
    }
    if (flavour == "ASPIRE") {
      image = const AssetImage("assets/images/aspire-background.jpeg");
    }

    return image;
  }

  static String getAppLogo() {
    const flavour = String.fromEnvironment('FLAVOR', defaultValue: 'ONTUM');
    String logo = "";
    if (flavour == "MEGHSHALA") logo = "assets/images/meghshala.png";
    if (flavour == "ASPIRE") logo = "assets/images/aspire.png";

    return logo;
  }

  static Future<List<Application?>> getMainApps() async {
    String appPackage = Config.getAppPackageName();
    List<String> apps = [
      appPackage,
      'org.learningequality.Kolibri',
      'org.jitsi.meet',
      'com.plickers.client.android',
    ];
   List<Future<Application?>> list = apps.map((a) async {
        Application? data = await DeviceApps.getApp(a, true);
        return data;
      }).toList();
      List<Application?> apps_list = await Future.wait(list);
      return apps_list;
  }
}
