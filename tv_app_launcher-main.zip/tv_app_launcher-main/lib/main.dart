import 'package:device_apps/device_apps.dart';
import 'package:flutter/material.dart';
import 'package:ontum_tv_launcher/Components/CleanerApp.dart';
import 'package:ontum_tv_launcher/Config/index.dart';
import 'package:ontum_tv_launcher/components.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App Launcher',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'App Launcher'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  static List<Application> _apps = [];
  SharedPreferences? _sharedPreferences;
  bool _isAdmin = false;
  bool _isVPN = false;
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();
  bool selected = false;
  ScrollController controller = ScrollController(keepScrollOffset: false);

  static AssetImage bgImage = Config.getAppBackgroundImage();

  Future initAllApps() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    bool? isAdmin = sharedPreferences.getBool("admin");

    List<Application> apps = await DeviceApps.getInstalledApplications(
        includeAppIcons: true,
        includeSystemApps: true,
        onlyAppsWithLaunchIntent: true);

    setState(() {
      _apps = apps;
      _sharedPreferences = sharedPreferences;
      if (isAdmin != null) _isAdmin = isAdmin;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    initAllApps();
    super.initState();
  }

  @override
  void didChangeDependencies() {
    precacheImage(bgImage, context);
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Container(
        height: height,
        width: width,
        decoration: BoxDecoration(
          color: Colors.black,
          image: DecorationImage(
            image: bgImage,
            colorFilter: ColorFilter.mode(
                Colors.black.withOpacity(0.6), BlendMode.dstATop),
            // opacity: 0.9,
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [body(width, height), footer()],
        ),
      ),
    );
  }

  Widget body(double width, double height) {
    return ListView(scrollDirection: Axis.vertical, children: [
      header(width, height),
      showMainApp(width, height, controller),
      allAppsHeader(width, _isAdmin),
      allApps(width, height, _apps, _isAdmin),
    ]);
  }

  Widget header(double width, double height) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        CleanerApp(height: height, width: width),
        logo(width),
        adminForm(
          width,
          context,
          _isAdmin,
          username,
          password,
          submitButton,
          selected,
          onSelected,
        )
      ],
    );
  }

  void onSelected(bool value) {
    (value) {
      if (value) {
        setState(() => value = true);
      } else {
        setState(() => value = false);
      }
    };
  }

  Widget submitButton() {
    return TextButton(
      child: Text(_isAdmin ? 'Logout' : 'Submit'),
      onPressed: () async {
        if (_isAdmin) {
          await _sharedPreferences!.setBool("admin", false);
          setState(() => _isAdmin = false);
          const snackBar = SnackBar(
            backgroundColor: Colors.green,
            content: Text('Logged-out successfully'),
          );
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
          Navigator.of(context).pop();
          return;
        }
        if (username.text == "admin" && password.text == "ontum@2022") {
          bool? isAdmin = await _sharedPreferences!.setBool("admin", true);
          setState(() {
            _isAdmin = isAdmin;
            username.text = "";
            password.text = "";
          });
          const snackBar = SnackBar(
            backgroundColor: Colors.green,
            content: Text('Logged-in successfully'),
          );
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
          Navigator.of(context).pop();
        } else {
          const snackBar = SnackBar(
            backgroundColor: Colors.amber,
            content: Text('Wrong username or password'),
          );
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        }
      },
    );
  }
}
