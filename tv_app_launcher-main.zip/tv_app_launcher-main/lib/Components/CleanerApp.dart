import 'package:device_apps/device_apps.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CleanerApp extends StatefulWidget {
  final double width;
  final double height;
  const CleanerApp({
    super.key,
    required this.height,
    required this.width,
  });

  @override
  State<CleanerApp> createState() => _CleanerAppState();
}

class _CleanerAppState extends State<CleanerApp> {
  bool selected = false;
  @override
  Widget build(BuildContext context) {
    return Focus(
      onFocusChange: (value) {
        if (value) {
          setState(() => selected = true);
        } else {
          setState(() => selected = false);
        }
      },
      onKeyEvent: (node, event) {
        if (event.physicalKey == PhysicalKeyboardKey.enter ||
            event.logicalKey == LogicalKeyboardKey.enter) {
          DeviceApps.openApp("com.charon.rocketfly");
          return KeyEventResult.handled;
        }
        return KeyEventResult.ignored;
      },
      child: Container(
        decoration: BoxDecoration(
            color: selected
                ? Colors.white30
                : const Color.fromRGBO(66, 86, 162, 1),
            borderRadius: BorderRadius.circular(50)),
        padding: const EdgeInsets.all(10),
        margin: const EdgeInsets.all(10),
        child: InkWell(
          onTap: () {
            DeviceApps.openApp("com.charon.rocketfly");
          },
          child: Icon(
            Icons.rocket_launch_outlined,
            size: widget.width * 0.05,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
