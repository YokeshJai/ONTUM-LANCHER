import 'package:device_apps/device_apps.dart';
import 'package:flutter/material.dart';
import 'package:ontum_tv_launcher/Components/AppContainer.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AllAppsSection extends StatelessWidget {
  final bool isAdmin;
  final List<Application> apps;
  final double height;
  final double width;

  AllAppsSection(
      {super.key,
      required this.isAdmin,
      required this.apps,
      required this.width,
      required this.height});

  int? selectedIndex;
  ScrollController controller = ScrollController(keepScrollOffset: false);

  @override
  Widget build(BuildContext context) {
    final double itemHeight = (height - kToolbarHeight - 26) / 2.5;
    final double itemWidth = width / 2;

    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: (itemWidth / itemHeight),
      ),
      controller: controller,
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      itemCount: apps.length,
      itemBuilder: ((context, index) {
        final app = apps[index];

        return AppContainer(app: app, height: height, width: width);
      }),
    );
  }
}
