import 'package:device_apps/device_apps.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../Config/index.dart';

class AppContainer extends StatefulWidget {
  final double width;
  final double height;
  final Application app;
  const AppContainer({
    super.key,
    required this.height,
    required this.width,
    required this.app,
  });

  @override
  State<AppContainer> createState() => _AppContainerState();
}

class _AppContainerState extends State<AppContainer> {
  bool selected = false;

  Future initTVeApp(packagename) async {
    bool isAspireInstalled = await DeviceApps.isAppInstalled(packagename);
    // #TODO: find a clean way to start up wireguard and connect to tunnel when the app is ontum TV app is started
    // bool isWGInstalled =
    //     await DeviceApps.isAppInstalled('com.wireguard.android');
    // if (_isVPN == false & isWGInstalled) {
    //   DeviceApps.openApp('com.wireguard.android');
    //   setState(() {
    //     _isVPN = true;
    //   });
    // }
    if (isAspireInstalled) {
      // DeviceApps.openApp("com.charon.rocketfly");
      // print(packagename);
      DeviceApps.openApp(packagename);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Focus(
      onFocusChange: (value) {
        if (value) {
          setState(() => selected = true);
        } else {
          setState(() => selected = false);
        }
      },
      onKeyEvent: (node, event) {
        if (event.physicalKey == PhysicalKeyboardKey.enter ||
            event.logicalKey == LogicalKeyboardKey.enter) {
          DeviceApps.openApp(widget.app.packageName);
          return KeyEventResult.handled;
        }
        return KeyEventResult.ignored;
      },
      child: InkWell(
        onTap: () {
          try {
            if (widget.app.packageName == Config.getAppPackageName()) {
              initTVeApp(widget.app.packageName);
            } else {
              DeviceApps.openApp(widget.app.packageName);
            }
          } catch (e) {
            print(e.toString());
          }
        },
        child: AnimatedContainer(
          duration: const Duration(seconds: 1),
          curve: Curves.fastOutSlowIn,
          margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: selected ? Colors.white30 : Colors.black45,
            borderRadius:
                BorderRadius.circular(widget.width * (selected ? 0.05 : .02)),
          ),
          width: widget.width * 0.3,
          height: widget.height * 0.2,
          child: Row(
            children: [
              Padding(
                padding: EdgeInsets.all(8),
                child: widget.app.packageName == "online.meghshala.edu"
                    ? Image.asset(
                        'assets/images/meghshala.png',
                        width: 100,
                        height: 100,
                      )
                    : Image.memory(
                        (widget.app as ApplicationWithIcon).icon,
                        width: selected ? 120 : 100,
                      ),
              ),
              Text(
                widget.app.appName,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize:
                      selected ? widget.width * 0.02 : widget.width * 0.015,
                  color: Colors.white,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
